# ===============================================
# CONFIGURAZIONE
# ===============================================

# --- JMeter Configuration (Host) ---
$JMeterEXEC_PATH = "C:\Users\giuse\Desktop\Impianti\apache-jmeter-5.6.3\bin\jmeter.bat"
# --- Modifica: Specifica la CARTELLA dei Test Plan ---
$JMX_DIR = "C:\Users\giuse\Desktop\Impianti\Progetto\Impianti-di-Elaborazione\Capacity\test_Plan"
$JTL_DIR = "C:\Users\giuse\Desktop\Impianti\Progetto\Impianti-di-Elaborazione\Capacity\JMeter_Logs"

# --- VM Configuration (Guest SSH) ---
$guestIP = "192.168.184.134" 
$guestUser = "giuleppe"
$guestPass = ConvertTo-SecureString "2406" -AsPlainText -Force 

# --- VMSTAT Settings ---
# --- Modifica: Durata impostata a 5 minuti (300 secondi) ---
$vmstatDurationSec = 300     # Durata fissa per vmstat
$vmstatSamplingRate = 1        

# ===============================================
# PREPARAZIONE
# ===============================================
Import-Module Posh-SSH -ErrorAction Stop

# Directory di destinazione per i log vmstat sul GUEST
$vmstatGuestDir = "/home/giuleppe/proveLLP"

# Cerca tutti i file JMX nella directory specificata
$jmxFiles = Get-ChildItem -Path $JMX_DIR -Filter *.jmx
if (-not $jmxFiles) {
    Write-Warning "ERRORE: Nessun file .jmx trovato nella directory $JMX_DIR"
    Read-Host "Premi Invio per uscire"
    exit 1
}

# Crea la directory di output JTL se non esiste (una sola volta)
if (-not (Test-Path $JTL_DIR)) {
    Write-Host "Creazione directory risultati: $JTL_DIR"
    New-Item -Path $JTL_DIR -ItemType Directory | Out-Null
}

Write-Host "========================================================"
Write-Host " AVVIO BATTERIA DI TEST"
Write-Host " Trovati $($jmxFiles.Count) file JMX in: $JMX_DIR"
Write-Host " Durata vmstat per ogni test: $vmstatDurationSec secondi"
Write-Host "========================================================"
Write-Host ""

# ===============================================
# ESECUZIONE SINCRONIZZATA - INIZIO CICLO
# ===============================================

# Itera su ogni file JMX trovato
foreach ($jmxFile in $jmxFiles) {

    # --- Calcolo Nomi File e Variabili (per questo ciclo) ---
    $currentJmxPath = $jmxFile.FullName
    $jmxFileName = [System.IO.Path]::GetFileNameWithoutExtension($currentJmxPath)
    
    $vmstatLogFileGuest = "$vmstatGuestDir/$jmxFileName" + "_vmstat_log.txt"
    $jtlPathHost = "$JTL_DIR\$jmxFileName" + "_risultati.csv"
    $jmeterArgs = "-n -t `"$currentJmxPath`" -l `"$jtlPathHost`""
    
    # Comando vmstat con durata fissa
    $vmstatCommand = "nohup vmstat $vmstatSamplingRate $vmstatDurationSec > $vmstatLogFileGuest 2>&1 &"

    Write-Host "--------------------------------------------------------"
    Write-Host "Avvio Test: $jmxFileName"
    Write-Host "--------------------------------------------------------"

    # --- Fase 1: Creazione Credenziali e Sessione SSH ---
    Write-Host "(GUEST) FASE 1: Creazione sessione SSH per $guestUser@$guestIP..."
    $sshCred = New-Object System.Management.Automation.PSCredential($guestUser, $guestPass)
    $sshSession = New-SSHSession -ComputerName $guestIP -Credential $sshCred -AcceptKey -ErrorAction SilentlyContinue

    if (-not $sshSession) {
        Write-Warning "ERRORE CRITICO: Creazione sessione SSH fallita. Salto il test $jmxFileName."
        Continue # Salta al prossimo file JMX nel ciclo
    }

    # --- Fase 1.5: Avvio di vmstat sul Guest (Background) ---
    Write-Host "(GUEST) Avvio di vmstat (durata fissa: $vmstatDurationSec secondi)..."
    Write-Host "(GUEST) Comando: $vmstatCommand"
    try {
        Invoke-SshCommand -SSHSession $sshSession -Command $vmstatCommand -ErrorAction Stop
    } catch {
        Write-Warning "ERRORE CRITICO: Esecuzione comando vmstat fallita. Salto il test $jmxFileName."
        Remove-SSHSession -SSHSession $sshSession
        Continue # Salta al prossimo file JMX nel ciclo
    }

    # Chiudiamo subito la sessione SSH
    Remove-SSHSession -SSHSession $sshSession
    Write-Host "(GUEST) Comando vmstat inviato. Sessione SSH chiusa."

    # --- Fase 2: Avvio di JMeter sull'Host ---
    Write-Host ""
    Write-Host "(HOST) FASE 2: Avvio di JMeter per $jmxFileName (attende la fine)..."
    
    # Avvia JMeter e attende che termini
    $jmeterProcess = Start-Process -FilePath $JMeterEXEC_PATH -ArgumentList $jmeterArgs -NoNewWindow -PassThru -Wait

    # --- Fase 3: Sincronizzazione e Attesa ---
    Write-Host ""
    Write-Host "(HOST) Test JMeter $jmxFileName Completato."
    Write-Host ""
    Write-Host "RISULTATI SALVATI:"
    Write-Host " - JMeter (Host): $jtlPathHost"
    Write-Host " - vmstat (Guest): $vmstatLogFileGuest (NON SCARICATO)"
    Write-Host ""

} # --- Fine del ciclo foreach ---

Write-Host "========================================================"
Write-Host " TUTTI I TEST SONO STATI COMPLETATI."
Write-Host "========================================================"

Read-Host "Premi Invio per chiudere"